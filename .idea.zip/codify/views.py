from django.shortcuts import render,  redirect
from .models import Course, Student
from django.http import HttpResponse
from .forms import CourseForm


def course_list(request):
    courses = Course.objects.all()
    return render(request, 'course_list.html', {'courses': courses})


def course_add(request):
    if request.method == "POST":
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('course_list')
        else:
            return HttpResponse("Error")
        # name = request.POST.get('name')
        # mentor_name = request.POST.get('mentor_name')
        # language = request.POST.get('language')
        # if name and mentor_name and language:
        #     course = Course.objects.create(name=name, mentor_name=mentor_name, language=language)
        # return HttpResponse('ГОТОВО')
    if request.method == "GET":
        form = CourseForm()
        return render(request, 'course_add.html', {'form': form})



